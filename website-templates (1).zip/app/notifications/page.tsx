import NotificationsPage from "@/pages/notifications"

export default function NotificationsRoute() {
  return <NotificationsPage />
}
