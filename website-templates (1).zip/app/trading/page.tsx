import Trading from "@/templates/trading"

export default function TradingPage() {
  return <Trading />
}
