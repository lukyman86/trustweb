import Register from "@/templates/register"

export default function RegisterPage() {
  return <Register />
}
